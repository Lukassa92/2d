﻿The SimpleSQL solution is organized into different runtimes, depending on the platform selected. 
All platforms projects are compiled before the editor project. The output files of each project 
platform are copied to the Editor project's Resources folder by way of a post-build script. These
project dlls are embedded as resources and extracted at runtime when the user selects a new platform.

Whenever you make a change to a runtime project, you will need to do one of two things to get the 
updates into your Unity project:

1) Open the SQL options window by Going to the Unity menu "Tools > SimpleSQL > Options". Click on a 
different platform than what is already selected (it doesn't matter which one you select). Wait a 
few seconds for the editor to extract the file and Unity to process the changes. You will see a
spinning wait icon appear, then go away. After that, you can switch back to the platform you would
like to use, wait a few seconds for Unity to process the updates, and then you will be ready to use
the updated runtime.

OR 

2) Just copy the results of the runtime project's build directly to your Unity project's SimpleSQL/Plugins
folder. Just be sure that you don't use the Editor options window if you employ this method because the
editor will stomp on whatever you copy manually.